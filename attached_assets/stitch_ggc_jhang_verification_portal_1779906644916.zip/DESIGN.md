---
name: Institutional Integrity System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#43474f'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737780'
  outline-variant: '#c3c6d0'
  surface-tint: '#3a6092'
  primary: '#002449'
  on-primary: '#ffffff'
  primary-container: '#0b3a6a'
  on-primary-container: '#81a5db'
  inverse-primary: '#a5c8ff'
  secondary: '#1d4ed8'
  on-secondary: '#ffffff'
  secondary-container: '#4069f2'
  on-secondary-container: '#fffbff'
  tertiary: '#142538'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a3a4f'
  on-tertiary-container: '#94a4bd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a5c8ff'
  on-primary-fixed: '#001c3a'
  on-primary-fixed-variant: '#1f4878'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b7c4ff'
  on-secondary-fixed: '#001551'
  on-secondary-fixed-variant: '#0039b5'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: IBM Plex Sans
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: IBM Plex Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is engineered for high-stakes academic administration, prioritizing **System Integrity** over casual student engagement. It targets government officials, university registrars, and students requiring official verification. The aesthetic is a fusion of **Corporate Modern** and **Minimalist Luxury**, evoking the gravitas of a central bank or a national security portal.

Visuals are characterized by high-density information architecture, surgical precision, and a "Secure-by-Design" atmosphere. We employ subtle grid patterns and micro-textures to suggest a ledger-like reliability. The emotional response should be one of absolute trust, permanence, and authoritative clarity.

## Colors
The palette is anchored in **Deep Navy (#0B3A6A)** to establish institutional authority and a "Gold Standard" feel. **Institutional Blue (#1D4ED8)** is used sparingly for primary actions and status indicators to maintain high-contrast accessibility. 

The background hierarchy utilizes **Light Gray (#F8FAFC)** for the page substrate, with **Pure White (#FFFFFF)** reserved for primary data cards and surfaces. Borders use a subtle Slate/Gray tint to define structure without adding visual noise. Status colors (Success/Error) are desaturated slightly to maintain the serious, professional tone of the portal.

## Typography
This design system utilizes **IBM Plex Sans** to leverage its technical, engineering-inspired skeleton. It communicates a "machine-perfect" accuracy. For numerical data points (GPAs, Serial Numbers, Credit Hours), use a monospaced variant to ensure alignment and prevent character confusion.

Typography is primarily set in Deep Navy for high legibility. Tracking is tightened on large headlines for a premium look, while labels utilize increased letter-spacing and uppercase styling to denote metadata categories. Use a strict hierarchy to manage high-density tables without cluttering the interface.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy for desktop (1440px max-width) to maintain a sense of controlled, secure architecture. A 12-column grid is used with generous 24px gutters. Content is organized into modular "Data Blocks" that allow for rapid scanning of academic results.

Horizontal density is high to accommodate complex transcripts, but vertical rhythm is strictly enforced with a 4px baseline unit. On mobile, the system collapses into a single-column stack, prioritizing data integrity over layout complexity. Use 64px outer margins on desktop to create a "letterhead" feel, framing the content as an official document.

## Elevation & Depth
Elevation is used to denote system layers rather than physical depth. 
1. **Base Layer:** Light Gray (#F8FAFC) substrate, occasionally featuring a 24px subtle dot-grid watermark in #E2E8F0.
2. **Surface Layer:** Pure White cards with 1px borders in #E2E8F0. No shadows are used on primary cards to maintain a "flat/secure" aesthetic.
3. **Glass Layer:** For secondary information panels or navigation sidebars, use a **Glassmorphic** effect (White 70% opacity, 12px Backdrop Blur). This adds a touch of modern luxury without compromising the portal's seriousness.
4. **Active State:** High-contrast Institutional Blue outlines signify focus. Avoid heavy drop shadows; use 2px tonal offsets if depth is required.

## Shapes
The shape language is **Soft (0.25rem)**. This slight rounding provides a modern touch while maintaining the structural rigidity expected of a government institution. Circular elements are strictly forbidden except for user avatars; all data containers, buttons, and input fields must use the standardized 4px corner radius. This consistency reinforces the "System Integrity" narrative.

## Components
- **Primary Buttons:** Solid Deep Navy background, white text, 4px radius. High-weight IBM Plex Sans.
- **Data Tables:** Zebra-striping using #F8FAFC, 1px horizontal dividers only. Header cells should have a subtle background and uppercase labels.
- **Verification Badges:** Small, rectangular chips with Institutional Blue borders and 10% opacity fills. Include a "Shield" icon for verified records.
- **Input Fields:** Crisp 1px borders. Focus state uses a 2px Institutional Blue ring. Use "Floating Labels" to maximize space in high-density forms.
- **Cards:** White surfaces with 1px #E2E8F0 borders. For official transcripts, include a faint background watermark of the institutional seal (5% opacity).
- **Status Indicators:** Small, solid dots (8px) for "Pass/Fail" or "Active/Inactive" status, paired with bold text.
- **Search Bar:** Minimalist, full-width with a glassmorphic background when used in the header, suggesting a modern, powerful search engine capability.